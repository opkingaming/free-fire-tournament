function requireUser(req, res, next) {
  if (!req.session.userId) {
    return res.redirect('/login');
  }
  next();
}

function requireAdmin(req, res, next) {
  if (!req.session.isAdmin) {
    return res.redirect('/admin/login');
  }
  next();
}

// Makes the logged-in user (if any) available in every view as `currentUser`
function attachUser(db) {
  return (req, res, next) => {
    res.locals.currentUser = null;
    if (req.session.userId) {
      const data = db.readDb();
      const user = data.users.find(u => u.id === req.session.userId);
      if (user) {
        res.locals.currentUser = { id: user.id, username: user.username, coins: user.coins };
      }
    }
    next();
  };
}

module.exports = { requireUser, requireAdmin, attachUser };
