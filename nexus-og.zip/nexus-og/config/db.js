// Nexus OG - simple file-based database
// No external database needed. All data lives in data/db.json.
// Good for a small/medium tournament site. If you outgrow this later,
// you can swap this module out for a real database without touching
// the rest of the app much, since everything goes through the functions below.

const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, '..', 'data', 'db.json');

function defaultData() {
  return {
    users: [],       // { id, username, password (hashed), coins, createdAt }
    deposits: [],     // { id, userId, amount, coins, method, screenshot, status, createdAt, decidedAt }
    rooms: [],         // { id, type, title, entryFee, roomId, roomPassword, startTime, status, players: [userId], createdAt }
    withdrawals: []    // reserved for future use
  };
}

function ensureDb() {
  if (!fs.existsSync(DB_PATH)) {
    fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
    fs.writeFileSync(DB_PATH, JSON.stringify(defaultData(), null, 2));
  }
}

function readDb() {
  ensureDb();
  const raw = fs.readFileSync(DB_PATH, 'utf-8');
  try {
    return JSON.parse(raw);
  } catch (e) {
    console.error('db.json is corrupted, resetting to empty database:', e);
    const fresh = defaultData();
    fs.writeFileSync(DB_PATH, JSON.stringify(fresh, null, 2));
    return fresh;
  }
}

// Very small write queue so two requests writing at the same time
// don't clobber each other's changes.
let writeChain = Promise.resolve();
function writeDb(data) {
  writeChain = writeChain.then(() => {
    return fs.promises.writeFile(DB_PATH, JSON.stringify(data, null, 2));
  });
  return writeChain;
}

module.exports = { readDb, writeDb, ensureDb, DB_PATH };
